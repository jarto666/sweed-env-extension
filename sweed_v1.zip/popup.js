document.addEventListener("DOMContentLoaded", () => {
  const envForm = document.getElementById("env-form");
  const featureOptions = document.getElementById("feature-options");
  const portalBtn = document.getElementById("portal-btn");
  const newShopBtn = document.getElementById("new-shop-btn");
  const oldShopBtn = document.getElementById("old-shop-btn");
  const marketingJobsBtn = document.getElementById("marketing-jobs-btn");
  const idInput = document.getElementById("feature-id");
  const storeInput = document.getElementById("store-id");

  const saveState = () => {
    const state = {
      environment: envForm.environment.value,
      project: envForm.project ? envForm.project.value : null,
      id: idInput.value,
      storeId: storeInput.value,
    };
    chrome.storage.local.set({ state });
  };

  const restoreState = () => {
    chrome.storage.local.get("state", (data) => {
      if (data.state) {
        if (data.state.environment) {
          document.querySelector(
            `input[name="environment"][value="${data.state.environment}"]`
          ).checked = true;
          if (data.state.environment === "feature") {
            featureOptions.style.display = "block";
          }
        }
        if (data.state.project) {
          document.querySelector(
            `input[name="project"][value="${data.state.project}"]`
          ).checked = true;
        }
        if (data.state.id) {
          idInput.value = data.state.id;
        }
        if (data.state.storeId) {
          storeInput.value = data.state.storeId;
        }
      } else {
        document.querySelector(
          `input[name="environment"][value="dev"]`
        ).checked = true;
        storeInput.value = "63";
      }
    });
  };

  document.querySelectorAll('input[name="environment"]').forEach((radio) => {
    radio.addEventListener("change", () => {
      featureOptions.style.display =
        radio.value === "feature" ? "block" : "none";
      saveState();
    });
  });

  document.querySelectorAll('input[name="project"]').forEach((radio) => {
    radio.addEventListener("change", saveState);
  });

  idInput.addEventListener("input", saveState);
  storeInput.addEventListener("input", saveState);

  const openTab = (url) => {
    console.log(url);
    chrome.tabs.create({ url });
  };

  const getSelectedEnvironment = () => {
    return envForm.environment.value;
  };

  const getParams = () => {
    return {
      project: envForm.project ? envForm.project.value : null,
      id: idInput.value,
      storeId: storeInput.value,
    };
  };

  portalBtn.addEventListener("click", () => {
    const env = getSelectedEnvironment();
    const { project, id } = getParams();
    if (env === "feature") {
      openTab(`https://${env}-${project}-${id}.sweedpos.com`);
    } else {
      openTab(`https://${env}.sweedpos.com`);
    }
  });

  newShopBtn.addEventListener("click", () => {
    const env = getSelectedEnvironment();
    const { project, id, storeId } = getParams();
    if (!storeId) storeId = 63;
    if (env === "feature") {
      openTab(
        `https://web-ui-${env}-${project}-${id}.sweedpos.com/s${storeId}`
      );
    } else {
      openTab(`https://web-ui-${env}.sweedpos.com/s${storeId}`);
    }
  });

  oldShopBtn.addEventListener("click", () => {
    const env = getSelectedEnvironment();
    const { project, id, storeId } = getParams();
    if (!storeId) storeId = 63;
    if (env === "feature") {
      openTab(`https://${env}-${project}-${id}.sweed.app?sid=${storeId}`);
    } else {
      openTab(`https://${env}.sweed.app?sid=${storeId}`);
    }
  });

  marketingJobsBtn.addEventListener("click", () => {
    const env = getSelectedEnvironment();
    openTab(
      `http://marketing-automation.${project}-${id}.svc.cluster.local:5005/jobs/recurring?from=0&count=5000`
    );
  });

  restoreState();
});
